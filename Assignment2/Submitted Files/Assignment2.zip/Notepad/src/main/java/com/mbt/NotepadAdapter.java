package com.mbt;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class NotepadAdapter {

   public String createFile(String s) {

       try {
           File f = new File("test.txt") ;
           f.createNewFile();
           Path path = Paths.get("test.txt");
           String pathName = path.toRealPath().toString();
           try (OutputStream outputStream = Files.newOutputStream(path)) {
               outputStream.write(s.getBytes());
           }
           Files.deleteIfExists(path);
           return pathName;

       } catch (IOException e){
           e.printStackTrace();
       }
       return s;
   }

    public void saveFile(String fileName,  String textToAppend)  {

        try {
            FileOutputStream outputStream = new FileOutputStream(fileName, true);
            byte[] strToBytes = textToAppend.getBytes();
            outputStream.write(strToBytes);

            outputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public String readFile(String fileName) {
       try{
           return Files.readAllLines(Paths.get(fileName)).get(0);
       } catch(Exception e) {
            e.printStackTrace();
            return null;
       }
   }



   /* public static void main(String ...s) throws Exception {
       NotepadAdaptor notepadAdaptor = new NotepadAdaptor();
       notepadAdaptor.createFile("This is text message ");
       notepadAdaptor.saveFile("xyz.txt");
       System.out.println(notepadAdaptor.readFile("xyz.txt"));
        notepadAdaptor.saveFile("xyz.txt");
        System.out.println( notepadAdaptor.readFile("xyz.txt"));

    }*/
}
package com.mbt;

import org.graphwalker.core.machine.ExecutionContext;
import org.graphwalker.java.annotation.AfterExecution;
import org.graphwalker.java.annotation.BeforeExecution;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import static org.junit.Assert.assertEquals;

public class NodePadModel extends ExecutionContext implements Notepad {

    NotepadAdapter notepadAdapter = new NotepadAdapter();
    String FILE_NAME = "demo.txt";
    String textToCreate = "Model based testing";
    String textToAppend = "Model based testing completed";

   public final static Path MODEL_PATH = Paths.get("com/mbt/Notepad.graphml");


    @BeforeExecution
    public void setup() throws IOException {
        System.out.println("Model: setup");
        Files.deleteIfExists(Paths.get(FILE_NAME));

    }

    @AfterExecution
    public void teardown() throws IOException {
        System.out.println("Model: teardown");
        Files.deleteIfExists(Paths.get(FILE_NAME));
    }
    @Override
    public void v_Start() {
        System.out.println("Running: v_Start");
    }

    @Override
    public void e_Init() {
        System.out.println("Running: e_Init");
    }

    @Override
    public void v_StartNotepad() {
        System.out.println("Running: v_StartNotepad");
    }

    @Override
    public void e_StartNotepad() {
        System.out.println("Running: e_StartNotepad");
    }

    @Override
    public void v_NotepadRunning() {
        System.out.println("Running: v_NotepadRunning");
    }

    @Override
    public void e_Create() {
        System.out.println("Running: e_Create");
        String fileName = notepadAdapter.createFile("This is sample text not to save in file");
        assertEquals(false, Files.exists(Paths.get(fileName)));
    }

    @Override
    public void v_Create() {
        System.out.println("Running: v_Create");
    }

    @Override
    public void e_Save() {
        System.out.println("Running: e_Save");
        notepadAdapter.saveFile(FILE_NAME, textToCreate);
        assertEquals(textToCreate, notepadAdapter.readFile(FILE_NAME));
    }

    @Override
    public void v_Save() {
        System.out.println("Running: v_Save");
    }

    @Override
    public void e_Close() {
        System.out.println("Running: e_Close");
    }

    @Override
    public void v_Edit() {
        System.out.println("Running: v_Edit");
    }

    @Override
    public void e_Edit() {
        System.out.println("Running: e_Edit");
    }

    @Override
    public void e_SaveEdit() {
        System.out.println("Running: e_SaveEdit");
        String readData = notepadAdapter.readFile(FILE_NAME) + textToAppend;
        notepadAdapter.saveFile(FILE_NAME, textToAppend);
        assertEquals(readData, notepadAdapter.readFile(FILE_NAME) + textToAppend);
    }

    @Override
    public void e_Exit() {
        System.out.println("Running: e_Exit");
    }

    @Override
    public void e_Postclose() {
        System.out.println("Running: e_Postclose");
    }

    @Override
    public void v_Close() {
        System.out.println("Running: v_Close");
    }


}
